package com.bpt.nt8ma;

/**
 * Created by Satyam on 7/15/2016.
 */
public class AppConfig {
    public static String URL_LOGIN = "http://198.57.174.253/plesk-site-preview/bestprotrade.com/198.57.174.253/nt8_ma/login.php";
    // Server user register url
    public static String URL_REGISTER = "http://198.57.174.253/plesk-site-preview/bestprotrade.com/198.57.174.253/nt8_ma/register.php";

    public static String URL_RESET = "http://198.57.174.253/plesk-site-preview/bestprotrade.com/198.57.174.253/nt8_ma/resetPassword.php";

    public static String URL_SYMBOL_UPDATE = "http://198.57.174.253/plesk-site-preview/bestprotrade.com/198.57.174.253/nt8_ma/updateSymbols.php";

    public static String URL_GET_SYMBOLS = "http://198.57.174.253/plesk-site-preview/bestprotrade.com/198.57.174.253/nt8_ma/getSymbols2.php";

    public static String URL_EXPIRY_UPDATE = "http://198.57.174.253/plesk-site-preview/bestprotrade.com/198.57.174.253/nt8_ma/expiryUpdate.php";
}